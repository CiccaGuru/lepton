<?php

namespace Lepton\Authenticator\AccessControlAttributes;

abstract class AbstractAccessControlAttribute
{

}
