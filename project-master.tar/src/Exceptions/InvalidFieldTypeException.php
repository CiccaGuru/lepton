<?php
namespace Lepton\Exceptions;

use Exception;

class InvalidFieldTypeException extends Exception{}