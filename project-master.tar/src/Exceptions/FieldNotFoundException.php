<?php
namespace Lepton\Exceptions;

use Exception;

class FieldNotFoundException extends Exception{}