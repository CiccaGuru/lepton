<?php
namespace Lepton\Exceptions;

use Exception;

class InvalidFieldException extends Exception{}