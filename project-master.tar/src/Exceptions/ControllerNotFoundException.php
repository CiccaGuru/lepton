<?php
namespace Lepton\Exceptions;

use Exception;

class ControllerNotFoundException extends Exception{}