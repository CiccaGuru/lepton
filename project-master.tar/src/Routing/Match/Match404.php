<?php

namespace Lepton\Routing\Match;


class Match404 extends BaseMatch
{

}
