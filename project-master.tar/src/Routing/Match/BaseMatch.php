<?php

namespace Lepton\Routing\Match;


class BaseMatch
{

}
